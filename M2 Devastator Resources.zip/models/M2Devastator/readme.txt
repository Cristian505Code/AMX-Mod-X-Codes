A big thanks to Arabas for the v_m2devastator.mdl!
Arabas YouTube: https://www.youtube.com/channel/UCsbhGk9Km28xKnnL5uMWN1g